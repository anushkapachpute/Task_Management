<?php

return [
    'site_title' => 'Event Reminders',
];
